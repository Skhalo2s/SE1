package Uebung4.control.exceptions;

public class WrongInputException extends Exception{
    public  WrongInputException (String m){
        super(m);
    }
}
