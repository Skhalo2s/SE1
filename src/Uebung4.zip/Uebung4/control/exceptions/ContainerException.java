package Uebung4.control.exceptions;

/**
 *
 * @author Salah Khalosi
 * @fachbereich_kuerzel skhalo2s
 * @vision 1.0
 *
 */

public class ContainerException extends Exception {
    public  ContainerException (String m){
        super(m);
    }

}
